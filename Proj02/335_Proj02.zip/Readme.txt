Mustafa Jebara-jebaramu
Daria Tarasova-tarasov1

Contributions: 
	Daria:
		Created main.cpp, EmployeeDatabaseSortby...h and edited Manager.h		
	Mustafa:
		Created UML model, Database Employee class, and made small changes to other classes

