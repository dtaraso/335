#ifndef CMANAGER_H
#define CMANAGER_H

#include "Employee.h"
#include <vector>

class CManager : public CEmployee {
protected:
    //Initializes department name and vector of employees
	string mDeptName;
	vector<CEmployee*> mEmployees;

public:
    //Constructor
	CManager(const string &firstName, const string &lastName,
		const unsigned short &salary, const tm &yearHired,
		const string &departName, const vector<CEmployee*> &group) :
		CEmployee(firstName, lastName, salary, yearHired) {
		mEmployees = group;
		mDeptName = departName;
	}

    //Copy Constructor
	CManager(const CManager& CM) :CEmployee(CM) {
		mDeptName = CM.mDeptName;
		mEmployees=CM.mEmployees;
	}
        
    //Assignment Operator
	CManager& operator = (const CManager& CM) {
		if (this != &CM) {
			mDeptName = CM.mDeptName;
			//mEmployees=CM.mEmployees;
			//CEmployee::operator =(CM);
		}
		return *this;
	}
        
    //Destructor
	~CManager() {
	}
	
    //Displays Employee aspects and department name of Manager
	virtual void DisplayEmployee(){
	CEmployee::DisplayEmployee();
	cout<<"\t"<<mDeptName; //<<"\t Subordinates:"<<mEmployees.size();
	//for(int i=0;i<mEmployees.size();i++){
	//cout<<"\tSubordinates:";
	//mEmployees[i]->DisplayEmployee();
	//}
	}
};

#endif /* CMANAGER_H */
