/* 
 * File:   EmployeeDatabaseSortbyFirstName.h
 * Author: Dasha
 *
 * Created on February 26, 2016, 4:55 PM
 */

#ifndef EMPLOYEEDATABASESORTBYFIRSTNAME_H
#define	EMPLOYEEDATABASESORTBYFIRSTNAME_H
#include "EmployeeDatabaseSortable.h"

class EmployeeDatabaseSortByFirstName: public EmployeeDatabaseSortable {
    public:
        //constructor
        EmployeeDatabaseSortByFirstName(vector <CEmployee*> employees):
    EmployeeDatabaseSortable(employees){};
    
        //function meant to detect if the current first name is smaller than next first name
        virtual bool smaller(int i, int j) const {
        if (getEmployee(i)->getFirstName() < getEmployee(j)->getFirstName())
            return true;
        else
            return false;
    }
};


#endif	/* EMPLOYEEDATABASESORTBYFIRSTNAME_H */
