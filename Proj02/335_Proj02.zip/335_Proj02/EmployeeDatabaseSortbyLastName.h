/*
* File:   EmployeeDatabaseSortbyLastName.h
* Author: Dasha
*
* Created on February 26, 2016, 4:56 PM
*/

#ifndef EMPLOYEEDATABASESORTBYLASTNAME_H
#define	EMPLOYEEDATABASESORTBYLASTNAME_H
#include "EmployeeDatabaseSortable.h"

class EmployeeDatabaseSortByLastName : public EmployeeDatabaseSortable {
public:
    //Constructor
	EmployeeDatabaseSortByLastName(vector <CEmployee*> employees) :
		EmployeeDatabaseSortable(employees) {};
    //Function detects if last name is smaller than next employee's last name
	virtual bool smaller(int i, int j) const {
		if (getEmployee(i)->getLastName() < getEmployee(j)->getLastName())
			return true;
		else
			return false;
	}
};


#endif	/* EMPLOYEEDATABASESORTBYLASTNAME_H */
