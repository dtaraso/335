/* 
 * File:   BubbleSortTemplate.h
 * Author: Dasha Tarasova
 *
 * Created on February 9, 2016, 1:50 PM
 */

#ifndef BUBBLESORTTEMPLATE_H
#define	BUBBLESORTTEMPLATE_H
#include "SortableVector.h"


class BubbleSortTemplate {
public:
    //Creates function that sorts by whether the previous value was smaller or not
    void sort(SortableVector* sortable){
        bool sorted = false;
        int n = sortable->getSize();
        //Goes into while loop and leaves once finishes vector
        while (!sorted){
            sorted = true;
            for (int i = 1; i < n; i++) {
                if (needSwap(sortable, i-1, i)) {
                    sortable->swap(i-1,i);
                    sorted = false;
                }
            }
            n--;
        }
    }
    //Creates virtual function that determines if values need to be swapped
    virtual bool needSwap(SortableVector* sortable, int i, int j) = 0;
};


#endif	/* BUBBLESORTTEMPLATE_H */

