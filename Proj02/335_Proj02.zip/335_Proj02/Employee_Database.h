#ifndef CDATABASE_H
#define CDATABASE_H
#include <vector>
#include "Employee.h"

class CDatabase {
protected:
    //Initializes vector of employees
    vector<CEmployee*> mRecords;
    
public:
    //Constructor
CDatabase(vector<CEmployee*> records) {
    mRecords=records;
}

//Copy Constructor
CDatabase(const CDatabase& CD) {
    mRecords=CD.mRecords;
}

//Assignment operator
CDatabase& operator = (const CDatabase& CD){
    if(this!=&CD){
        mRecords=CD.mRecords;
    }
    return *this;
}

//Destructor
~CDatabase() {
}

//Adds new employee to database
void AddRecord(CEmployee* CE){
    mRecords.push_back(CE);
}
//Displays all employees in vector
void DisplayRecords(){
    for(int i=0;i<mRecords.size();i++){
        mRecords[i]->DisplayEmployee();
    }
}
//returns employee
CEmployee* getEmployee(int i ) const{
		return mRecords[i];
	}
};

#endif /* CDATABASE_H */

