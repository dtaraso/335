Daria Tarasova - tarasov1
Mustafa Jebara - jebaramu

Contributions:
	Daria:
		UML Diagram, Employee, Manager, SumsalaryVisitor
	Mustafa:
		Group, Department, PrintVisitor
