#ifndef UNIT_H
#define	UNIT_H

#include "Visitor.h"

class Unit {
public:
	
	//Accepts Visitors
	virtual void Accept(Visitor*) = 0;
};


#endif	/* UNIT_H */
